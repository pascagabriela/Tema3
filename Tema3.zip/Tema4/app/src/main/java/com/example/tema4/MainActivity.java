package com.example.tema4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageView img;
    Image1 img1;
    Image2 img2;
    Image3 img3;
    Image4 img4;
    Image5 img5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img1 = new Image1();
        img2 =  new Image2();
        img3 =  new Image3();
        img4 =  new Image4();
        img5 =  new Image5();
        replaceFragment(new Image1());
    }

    public void showPrev(View view){
        if(currentFragment() instanceof Image1){
            replaceFragment(new Image5());
        }
        else if(currentFragment() instanceof Image2){
            replaceFragment(new Image1());
        }else if(currentFragment() instanceof Image3){
            replaceFragment(new Image2());
        }else if(currentFragment() instanceof Image4){
            replaceFragment(new Image3());
        }else if(currentFragment() instanceof Image5){
            replaceFragment(new Image4());
        }
    }

    public void showNext(View view){
        if(currentFragment() instanceof Image1){
            replaceFragment(new Image2());
        }
        else if(currentFragment() instanceof Image2){
            replaceFragment(new Image3());
        }else if(currentFragment() instanceof Image3){
            replaceFragment(new Image4());
        }else if(currentFragment() instanceof Image4){
            replaceFragment(new Image5());
        }else if(currentFragment() instanceof Image5){
            replaceFragment(new Image1());
        }
    }

    public Fragment currentFragment() {

        return getSupportFragmentManager().findFragmentById(R.id.frameLayout);
    }

    public void replaceFragment(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frameLayout, fragment);
        fragmentTransaction.commit();
    }

    public void showDetails(View view){
        Intent intent_1 = new Intent(this, MainActivity2.class);

        if(currentFragment() instanceof Image1){
            intent_1.putExtra("name_key", "The Starry Night");
        }else if(currentFragment() instanceof Image2){
            intent_1.putExtra("name_key", "Tulips field");
        }else if(currentFragment() instanceof Image3){
            intent_1.putExtra("name_key", "The valley");
        }else if(currentFragment() instanceof Image4){
            intent_1.putExtra("name_key", "Tree");
        }else if(currentFragment() instanceof Image5){
            intent_1.putExtra("name_key", "Two crabs");
        }
        startActivity(intent_1);
    }
}